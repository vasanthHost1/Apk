package com.foxxy.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.media.app.NotificationCompat.MediaStyle;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;

public class PlaybackService extends Service {
    private static final String CHANNEL = "foxxy_playback";
    private static final int NOTIFICATION_ID = 2002;
    private MediaSessionCompat mediaSession;
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        mediaSession = new MediaSessionCompat(this, "FoxxyMusic");
        mediaSession.setCallback(new MediaSessionCompat.Callback() {
            @Override public void onPlay() { MainActivity.runJs("try{player.playVideo()}catch(e){}"); updateState(true); }
            @Override public void onPause() { MainActivity.runJs("try{player.pauseVideo()}catch(e){}"); updateState(false); }
            @Override public void onSkipToNext() { MainActivity.runJs("try{if(typeof nextSong==='function')nextSong()}catch(e){}"); }
            @Override public void onSkipToPrevious() { MainActivity.runJs("try{if(typeof previousSong==='function')previousSong()}catch(e){}"); }
        });
        mediaSession.setActive(true);
        acquireCpuLock();
        startForeground(NOTIFICATION_ID, buildNotification(false));
    }

    private void updateState(boolean playing) {
        long actions = PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_PAUSE
                | PlaybackStateCompat.ACTION_SKIP_TO_NEXT | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS;
        int state = playing ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED;
        mediaSession.setPlaybackState(new PlaybackStateCompat.Builder().setActions(actions).setState(state, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 1f).build());
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.notify(NOTIFICATION_ID, buildNotification(playing));
    }

    private Notification buildNotification(boolean playing) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Foxxy Music")
                .setContentText(playing ? "Playing" : "Foxxy Music is ready")
                .setContentIntent(content)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setStyle(new MediaStyle().setMediaSession(mediaSession.getSessionToken()).setShowActionsInCompactView(0,1,2))
                .addAction(new NotificationCompat.Action(android.R.drawable.ic_media_play, "Play", mediaButton("play")))
                .addAction(new NotificationCompat.Action(android.R.drawable.ic_media_pause, "Pause", mediaButton("pause")))
                .addAction(new NotificationCompat.Action(android.R.drawable.ic_media_next, "Next", mediaButton("next")))
                .build();
    }

    private PendingIntent mediaButton(String action) {
        Intent i = new Intent(this, PlaybackService.class).setAction(action);
        return PendingIntent.getService(this, action.hashCode(), i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case "play": MainActivity.runJs("try{player.playVideo()}catch(e){}"); updateState(true); break;
                case "pause": MainActivity.runJs("try{player.pauseVideo()}catch(e){}"); updateState(false); break;
                case "next": MainActivity.runJs("try{if(typeof nextSong==='function')nextSong()}catch(e){}"); break;
            }
        }
        return START_STICKY;
    }

    private void acquireCpuLock() {
        PowerManager pm = (PowerManager)getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FoxxyMusic:Playback");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, getString(com.foxxy.music.R.string.channel_name), NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Foxxy Music background playback");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (mediaSession != null) { mediaSession.setActive(false); mediaSession.release(); }
        super.onDestroy();
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}
