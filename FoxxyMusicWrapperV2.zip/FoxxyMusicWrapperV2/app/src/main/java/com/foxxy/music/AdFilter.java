package com.foxxy.music;

import java.util.Locale;

final class AdFilter {
    private static final String[] HOST_PARTS = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "adsrvr.org", "taboola.com",
        "outbrain.com", "criteo.com", "scorecardresearch.com", "zedo.com"
    };
    static boolean shouldBlock(String url) {
        String u = url.toLowerCase(Locale.US);
        for (String h : HOST_PARTS) if (u.contains(h)) return true;
        return u.contains("/pagead/") || u.contains("/adsystem/") || u.contains("/adserver/");
    }
}
