# Foxxy Music Android Wrapper v2

This is a wrapper around the exact `index.html` extracted from the user's working APK. The HTML source is copied unchanged into `app/src/main/assets/index.html`.

## V2 goal
Target background/minimized playback without changing the Foxxy Music web app:
- foreground media playback service
- Android MediaSession transport controls
- WebView renderer priority bound on supported Android versions
- CPU partial wake lock while the service is running
- autoplay setting enabled
- conservative request-level ad filtering
- external navigation restricted to the media/API hosts used by the app

## Important limitation
The music player is a YouTube IFrame. A native foreground service can keep the Android process alive, but it cannot guarantee that YouTube's embedded WebView player will continue playing when Android hides the Activity or when the device locks. This build is intended to test the behavior on a real device without modifying the web app.

## Build
Open this folder in Android Studio and let Gradle sync. Build > Build APK(s).

The project uses Android Gradle Plugin 8.6.1, compileSdk 35, minSdk 23, and AndroidX Media/AppCompat.
